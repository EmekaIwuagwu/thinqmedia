module.exports=[41908,(a,b,c)=>{}];

//# sourceMappingURL=69685_thinqmedia__next-internal_server_app__global-error_page_actions_47b38f61.js.map